/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","cy",{title:"Dewisydd Lliwiau'r UI",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Setiau lliw wedi'u cyn-ddiffinio",config:"Gludwch y llinyn hwn i'ch ffeil config.js"});