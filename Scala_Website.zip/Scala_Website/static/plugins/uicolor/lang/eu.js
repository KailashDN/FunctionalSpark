/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","eu",{title:"EI kolore-hautatzailea",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Aurrez definitutako kolore multzoak",config:"Itsatsi kate hau zure config.js fitxategian"});